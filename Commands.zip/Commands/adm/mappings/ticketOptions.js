// mappings/ticketOptions.js

module.exports = {
    "opc1": "Instagram",
    "opc2": "TikTok",
    "opc3": "YouTube",
    "opc4": "Ativação Nitro",
    "opc5": "Conta-Discord",
    "opc6": "Nitro-Mensal",
    "opc7": "Nitro-Trimensal",
    "opc8": "Nitro-Gift-Mensal",
    "opc9": "Serviços de Streaming",
    "opc10": "Sala personalizada Free Fire",
    "opc11": "Ativação Windows",
    "opc12": "Cidade MTA",
    "opc13": "Bots Discord"
};
